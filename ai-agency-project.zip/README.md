# Build AI Agency

Build AI Agency is a small, practical AI-agent starter project.

The idea is simple: instead of using AI only for chat, the project organizes useful tasks into specialized agents. Each agent has a clear role, a goal, and a simple workflow.

## What is included

- **Research Agent** — turns a topic into a structured research brief.
- **Content Agent** — creates social-media content ideas from a brief.
- **Task Planner** — breaks a goal into actionable steps.
- A lightweight command-line interface for trying the agents.

This is an early version designed to be easy to understand and extend.

## Run it

Requirements: Python 3.10+

```bash
python main.py
```

No external API key is required for the demo. The agents use simple local logic so the project can be tested immediately.

## Roadmap

- Connect real LLM providers
- Add persistent agent memory
- Add web research tools
- Add a web dashboard
- Add multi-agent workflows
