from src.agents import ResearchAgent, ContentAgent, TaskPlanner


def main():
    print("Build AI Agency")
    print("----------------")
    print("1. Research Agent")
    print("2. Content Agent")
    print("3. Task Planner")

    choice = input("\nChoose an agent (1-3): ").strip()
    request = input("What do you want the agent to work on? ").strip()

    agents = {
        "1": ResearchAgent(),
        "2": ContentAgent(),
        "3": TaskPlanner(),
    }

    agent = agents.get(choice)
    if not agent:
        print("Invalid choice.")
        return

    print("\nResult:\n")
    print(agent.run(request))


if __name__ == "__main__":
    main()
