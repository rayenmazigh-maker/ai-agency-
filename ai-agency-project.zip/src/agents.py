class BaseAgent:
    name = "Base Agent"

    def run(self, request: str) -> str:
        raise NotImplementedError


class ResearchAgent(BaseAgent):
    name = "Research Agent"

    def run(self, request: str) -> str:
        return (
            f"Research brief for: {request}\n\n"
            "1. Define the topic clearly.\n"
            "2. Identify the main questions to answer.\n"
            "3. Collect reliable sources and compare them.\n"
            "4. Summarize the key findings.\n"
            "5. List open questions and next steps."
        )


class ContentAgent(BaseAgent):
    name = "Content Agent"

    def run(self, request: str) -> str:
        return (
            f"Content ideas for: {request}\n\n"
            "• Short educational post\n"
            "• Behind-the-scenes video\n"
            "• 3 quick tips carousel\n"
            "• Problem → solution post\n"
            "• Personal story with a practical takeaway"
        )


class TaskPlanner(BaseAgent):
    name = "Task Planner"

    def run(self, request: str) -> str:
        return (
            f"Plan for: {request}\n\n"
            "Step 1 — Define the final result.\n"
            "Step 2 — Split the goal into smaller tasks.\n"
            "Step 3 — Prioritize the highest-impact task.\n"
            "Step 4 — Execute and test.\n"
            "Step 5 — Review the result and improve it."
        )
